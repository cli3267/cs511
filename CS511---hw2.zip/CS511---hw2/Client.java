import java.util.*; 

// there are some errors here
public class Client {
    // these are used to generate a random routine
    private static final int max = 20;
    private static final int min = 15;
    private static Random randomno = new Random();
    private static Random randomnum = new Random();

    private int id;
    private List<Exercise> routine;

    public Client(int id){
        this.id = id;
        this.routine = new ArrayList<Exercise>();
    }

    // this function will generate a routine for the client
    public Client generateRoutine(int id) {
        // n is a random number from 15-20 
        int n = randomno.nextInt(max - min + 1) + 1;
        Client client = new Client(id);
        Map<WeightPlateSize, Integer> eachExercise = new HashMap<WeightPlateSize, Integer>();

        for(int i=0 ; i<=n; i++){
            WeightPlateSize weights = WeightPlateSize.randomGen();
            Integer exerciseInt = randomnum.nextInt((10-0) + 1);
            eachExercise.put(weights, exerciseInt);
            client.addExercise(Exercise.generateRandom(eachExercise));
        }
        return client;
    }

    public void addExercise(Exercise e){
        this.routine.add(e);
    }

    public static Client generateRandom(int id){
        Client client = new Client(id);
        return client;
    } 
}
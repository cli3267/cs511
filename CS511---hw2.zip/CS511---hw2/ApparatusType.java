import java.util.*;

// Contains the declaration given above 
// and possibly methodsfor generating a random apparatus type.

public enum ApparatusType {
    LEGPRESSMACHINE, BARBELL, HACKSQUATMACHINE, LEGEXTENSIONMACHINE, LEGCURLMACHINE, LATPULLDOWNMACHINE, PECDECKMACHINE, CABLECROSSOVERMACHINE;

    // this grabs all the values in the enum and stores it into the array
    private static ApparatusType[] apparatus = ApparatusType.values();

    // generates a new random
    public static Random randomno = new Random();
    
    public static ApparatusType randomGen() {
        // n generates a random number from 0 to the length of apparatus
        int n = randomno.nextInt(apparatus.length);
        return apparatus[n];
    }
    public static void main(String[] args) {
        System.out.print(ApparatusType.randomGen());
    }

}

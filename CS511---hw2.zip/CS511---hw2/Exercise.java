import java.util.*; 

public class Exercise{
    private ApparatusType apparatusType;
    private Map<WeightPlateSize, Integer> weight; 
    private int duration;
    
    public Exercise(ApparatusType apparatusType, Map<WeightPlateSize, Integer> weight, int duration){
        this.apparatusType = apparatusType;
        this.weight = weight;
        this.duration = duration;
    }

    public static Exercise generateRandom(Map<WeightPlateSize, Integer> weight){
        Exercise exercise = new Exercise(ApparatusType.randomGen(), weight, 5);
        return exercise;
    }
}
// package Assignment2;
import java.util.*;
/** start the simulation */
public class Assignment2 {
	public static void main (String [] args) {
		Thread thread = new Thread(new Gym()); //Gym will always be the same, no need to pass args
		thread.start();
		try {
			thread.join();
		} catch (InterruptedException e) {
			// TODO Auto - generated catch block
			e.printStackTrace();
		}
	}
}
import java.util.*;
import java.util.concurrent.Semaphore;
// finish this function, and also package all these classes up

public class Gym {
    private static final int GYM_SIZE = 30;
    private static final int GYM_REGISTERED_CLIENTS = 10000; 
    private Map<WeightPlateSize, Integer> noOfWeightPlates;
    private Set<Integer> clients; // for generating fresh client ids private ExecutorService executor;

    // various semaphores - declaration omitted 
    // each apparatus only has 5 machines in the gym
    Semaphore LEGPRESSMACHINE = new Semaphore(5);
    Semaphore BARBELL = new Semaphore(5);
    Semaphore HACKSQUATMACHINE = new Semaphore(5);
    Semaphore LEGEXTENSIONMACHINE = new Semaphore(5); 
    Semaphore LEGCURLMACHINE = new Semaphore(5);
    Semaphore LATPULLDOWNMACHINE = new Semaphore(5);
    Semaphore PECDECKMACHINE = new Semaphore(5); 
    Semaphore CABLECROSSOVERMACHINE = new Semaphore(5);

    public void run(){
        // geting a list of clients
        Client[] clients = new Client[GYM_REGISTERED_CLIENTS];

        for(int i = 0; i < GYM_REGISTERED_CLIENTS; i++){
            Client client = new Client(i);
            client = client.generateRoutine(i);
            System.out.print(client);
        }
    }
}
import java.util.*; 

// Contains the declaration given above and possibly methods
// for generating a random weight plate size.

public enum WeightPlateSize {
    SMALL_3KG, MEDIUM_5KG, LARGE_10KG;
    
    // this grabs all the values in the enum and stores it into the array
    private static WeightPlateSize[] weightArr = WeightPlateSize.values();

    // generates a new random 
    public static Random randomno = new Random();
        
    public static WeightPlateSize randomGen() {
        // n is the a random number between 0 to 10,
        // this does not include 11
        int n = randomno.nextInt(3);
        return weightArr[n];
    }
    public static void main(String[] args) {
        System.out.print(WeightPlateSize.randomGen());
    }
}